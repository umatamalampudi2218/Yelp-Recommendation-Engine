from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession
from pyspark import SparkConf
from pyspark.sql.functions import col

conf = SparkConf().setMaster("local[*]").set("spark.executor.memory", "16g")

sc = SparkContext(conf=conf)
spark = SparkSession(sc).builder.getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

# Read data with date casting and partition-wise sort
df = spark.read.format("csv") \
    .option("header", "true") \
    .option("multiline", "true") \
    .load("yelp_review.csv")

df.printSchema()
df.show()
print(f"total rows", df.count())

# Select and sort last 3 million records
df_last_3m = df.limit(3000000)

# Write the DataFrame to a CSV file
df_last_3m.write.csv("yelp_review_cleaned", header=True)
print(f"row count", df_last_3m.count())

# Stop SparkSession
spark.stop()
